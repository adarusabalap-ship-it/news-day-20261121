# make.fun build sessions

When this session opens with the user's make.fun bounty request, first read
C:~ S I/.makefun/active-build.json. If it holds {"slug", "brief"}, read that
brief file and follow it exactly: it is the build plan the user delegated for that
competition. If the file is absent or names no brief, act on the user's request
normally.
